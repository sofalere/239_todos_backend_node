1. the format of the year
- I made changes to the `Todo.getDueDate()` method, specifically adding the `slice` function on line `254`

2. removing a set date
- I had to make a few changes to accomplish this requirement. First, in the `Controller.formatForServer` method on line 398. The API docs would only accept 2 or 4 length strings for changes to the `month` or `year` fields, to accomodate this when a form selections value is `Day` or `Month` the server will receive `00` and `0000` for the `Year`. The updated todos output returned by the API would now include the `00` strings and so I added some conditions to the `Todo` constructor on line 240 and the `Todo.getDueDate()` method on line `252` to deal with the variable data. 